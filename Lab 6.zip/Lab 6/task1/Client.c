#include <stdio.h> 
#include <stdlib.h> 
#include <unistd.h> 
#include <string.h> 
#include <sys/types.h> 
#include <sys/socket.h> 
#include <arpa/inet.h> 
#include <netinet/in.h> 
#include<pthread.h>
#define PORT	 8084
#define MAXLINE 1024

struct info
{
	char* ip;
	int port;
	int fd;
};
void*seend(void*ptr)
{
	int*sockfd = (int*)ptr;
	char msg[MAXLINE];
	int n=0,i=0;
	while(i<10)
	{
		printf("\nEnter Message to Send :");
		fgets(msg,1024,stdin);
		send(sockfd[0],(const char*)msg,strlen(msg),0);
		i++;
	}
	close(sockfd[0]);
	
}
void*recieve(void*ptr)
{
	int *sockfd= (int*)ptr;
	char msg[MAXLINE];
	int n=0,i=0;
	while(i<10)
	{
		n=recv(sockfd[0],msg,sizeof(msg),0);
		msg[n]='\0';
		i++;
		printf("Message Recieved from Server = %s",msg);
	}
//	close(sockfd);
}
int main()
{
	int* sockfd = (int*)malloc(sizeof(int));
	struct sockaddr_in servaddr;
	sockfd[0] = socket(AF_INET,SOCK_STREAM,0);
	if(sockfd[0]<0)
	{
		perror("Socket Creation Failed");
		exit(-1);
	}
	servaddr.sin_family = AF_INET; // IPv4 
	servaddr.sin_addr.s_addr = INADDR_ANY; 
	servaddr.sin_port = htons(PORT);
	connect(sockfd[0],(const struct sockaddr*)&servaddr,sizeof(servaddr));  
	pthread_t tid1,tid2;	
	pthread_create(&tid1,NULL,seend,(void*)sockfd);
	pthread_create(&tid2,NULL,recieve,(void*)sockfd);
	pthread_exit(&tid1);
	pthread_exit(&tid2);



return 0;
}
