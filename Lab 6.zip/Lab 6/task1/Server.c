#include <stdio.h> 
#include <stdlib.h> 
#include <unistd.h>
#include <pthread.h>
#include <signal.h>
#include <string.h> 
#include <sys/types.h> 
#include <sys/socket.h> 
#include <arpa/inet.h> 
#include <netinet/in.h> 

#define PORT	 8084
#define MAXLINE 1024
int sockfd;
struct info
{
	char* ip;
	int port;
	int fd;
};
void*func(void*d)
{
	struct info *clientinfo =(struct info*)d;
	char msg[MAXLINE];
	int n =0,i=0;

	while(i<10)
	{
		n = recv(clientinfo->fd, msg, sizeof(msg), 0);
		msg[n]='\0';
		printf("\nMessage Recieved From Client: %s\n",msg);
		printf("\nEnter Message tp send to Client: ");
		fgets(msg,1024,stdin);
		send(clientinfo->fd, (const char *)msg, strlen(msg), 0);
		
		i++;
	 }

}

int main()
{
	sockfd=socket(AF_INET ,SOCK_STREAM, 0);
	if(sockfd<0)
	{
		perror("Socket Creation Failed");
		exit(-1);
	}
	struct sockaddr_in servaddr, cliaddr;
	memset(&cliaddr, 0, sizeof(cliaddr));
	memset(&cliaddr, 0, sizeof(servaddr));
	servaddr.sin_family = AF_INET; // IPv4 
	servaddr.sin_addr.s_addr = INADDR_ANY; 
	servaddr.sin_port = htons(PORT);
	//memset(&buffer, 0, sizeof(buffer));
	if(bind(sockfd, (const struct sockaddr *)&servaddr, sizeof(servaddr))<0)
	{
		perror("Bind Failed");
		exit(-1);
	}
	listen(sockfd, 10);
	int n=0,newsock;
	
	pthread_t tid;
	while(1)
	{
		n = sizeof(cliaddr);
		newsock = accept(sockfd,(struct sockaddr*)&cliaddr,&n);
		struct info*i=malloc(sizeof(struct info));
		i->ip = inet_ntoa(cliaddr.sin_addr);
		i->port = ntohs(cliaddr.sin_port);
		i->fd=newsock;
		int s = pthread_create(&tid,NULL,func,(void*)i);
	}
	pthread_exit(&tid);
	
return 0;
}
