#include<pthread.h>
#include <stdio.h> 
#include <stdlib.h> 
#include <unistd.h> 
#include <string.h> 
#include <sys/types.h> 
#include <sys/socket.h> 
#include <arpa/inet.h> 
#include <netinet/in.h>
#include <time.h>
#include <signal.h> 
#define PORT 8080
#define MAXLINE 1024

void error(char *msg){
    perror(msg);
    exit(1);
}
struct str
{
	char* ip;
	int port;
	int newsockfd;
};

void* function(void* data)
{
	struct str *information = (struct str*)data;
	char msg[MAXLINE];
	memset(msg, '\0', MAXLINE);
	
    while(1)
    {
        int n = recv (information->newsockfd, msg, MAXLINE, 0);
        msg[n] = '\0';
        printf("Client with Port %d | Message %s\n",information->port , msg);

        if(strcmp(msg, "EXIT") == 0)
        {
            send(information->newsockfd, "EXIT", strlen("EXIT"), 0);
            break;
        }
        memset(msg, '\0', MAXLINE);
        sprintf(msg, "Client Port %d and IP Address %s", information->port, information->ip);
        send(information->newsockfd, msg, strlen(msg), 0);
    }
	close(information->newsockfd);
	pthread_exit(NULL);
}

int main()
{
    int sockfd;
    char buffer[MAXLINE]; 
    struct sockaddr_in servaddr, cliaddr;
    char *hello = "Hello from server"; 
    sockfd = socket(AF_INET, SOCK_STREAM, 0);
    memset(&servaddr, 0, sizeof(servaddr));
    memset(&cliaddr, 0, sizeof(cliaddr));

    servaddr.sin_family = AF_INET;
    servaddr.sin_addr.s_addr = INADDR_ANY;
    servaddr.sin_port = htons(PORT);

    bind(sockfd, (const struct sockaddr *)&servaddr, sizeof(servaddr));
    listen(sockfd, 10);

    pthread_t tid[10];
    int n;
    int len;
    int newsockfd;

    printf("Server is running and now waiting for client.\n");
    int inc = 0;
    while(1)
    {
        len = sizeof(cliaddr);
        newsockfd = accept(sockfd, (struct sockaddr*)&cliaddr, &len);
        printf("\nClient with port %d" " connected \n", ntohs(cliaddr.sin_port));
        struct str* information = malloc(sizeof(struct str));
		information->ip = inet_ntoa(cliaddr.sin_addr);
		information->port = ntohs(cliaddr.sin_port);
		information->newsockfd = newsockfd;

        pthread_create(&tid[1], NULL, function, (void*)information);
        if(tid[inc] < 0){
			error("Error occured while creating thread.\n");
		}
		if(tid[inc] == 0){
			close(sockfd);
			exit(0);
		}
		inc++;
    }
    int i = 0;
	for(i = 0; i <= inc; i++)
    {
		pthread_join(tid[i], NULL);
	}
    return 0;
}