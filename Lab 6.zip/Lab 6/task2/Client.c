#include <stdio.h> 
#include <stdlib.h> 
#include <unistd.h> 
#include <string.h> 
#include <sys/types.h> 
#include <sys/socket.h> 
#include <arpa/inet.h> 
#include <netinet/in.h> 
#include<pthread.h>
#define PORT 8084
#define MAXLINE 1024

void*seend(void*ptr)
{
	int*sockfd = (int*)ptr;
	char msg[MAXLINE];
	memset(msg,'\0',MAXLINE);
	printf("\nEnter Message to Send :");
	fgets(msg,1024,stdin);
	send(sockfd[0],(const char*)msg,strlen(msg),0);	
}
void*recieve(void*ptr)
{
	char msg[MAXLINE];	
	int *sockfd= (int*)ptr;
	memset(msg,'\0',MAXLINE);	
	//char msg[MAXLINE];
	int n=0;
	n=recv(sockfd[0],msg,sizeof(msg),0);
	msg[n]='\0';
	printf("\nMessage Recieved from Server = %s\n",msg);
}
int main()
{
	int sockfd;
	struct sockaddr_in servaddr;
	sockfd = socket(AF_INET,SOCK_STREAM,0);
	if(sockfd<0)
	{
		perror("Socket Creation Failed");
		exit(-1);
	}
	servaddr.sin_family = AF_INET; // IPv4 
	servaddr.sin_addr.s_addr = INADDR_ANY; 
	servaddr.sin_port = htons(PORT);
	connect(sockfd,(const struct sockaddr*)&servaddr,sizeof(servaddr));
 
//	pthread_t tid1,tid2;
	char msg[MAXLINE];
	int n=0;
	while(1)
	{
		scanf("%s",msg);
		send(sockfd,msg,strlen(msg),0);
		n=recv(sockfd,msg,MAXLINE,0);
		msg[n]='\0';
		printf("Message Recieved From Server :%s\n",msg);
		if(strcmp(msg,"EXIT")==0)
			break;
	}
	close(sockfd);
return 0;
}
