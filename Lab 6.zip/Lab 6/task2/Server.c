#include <stdio.h> 
#include <stdlib.h> 
#include <unistd.h>
#include <pthread.h>
#include <signal.h>
#include <string.h> 
#include <sys/types.h> 
#include <sys/socket.h> 
#include <arpa/inet.h> 
#include <netinet/in.h>
#define PORT	 8084
#define MAXLINE 1024
int sockfd;
int number=0;
struct info
{
	char* ip;
	int port;
	int fd;
};
void*func(void*d)
{
	struct info *cinfo =(struct info*)d;
	char msg[MAXLINE];
	memset(msg,'\0',MAXLINE);
	int n;
	while(1)
	{
		n = recv(cinfo->fd, msg, sizeof(msg), 0);
		msg[n]='\0';
		printf("Client with Port %d\tIp %s",cinfo->port,cinfo->ip);
		printf("\nMessage Recieved From Client: %s\n",msg);
		if(strcmp(msg,"EXIT")==0)
		{
			send(cinfo->fd,"EXIT",strlen("EXIT"),0);
			break;
		}
		memset(msg,'\0',MAXLINE);
		sprintf(msg,"Client Port %d\tIP Address %s",cinfo->port,cinfo->ip);
		send(cinfo->fd,msg,strlen(msg),0);
	}
	close(cinfo->fd);
	pthread_exit(NULL);
}

int main()
{
	sockfd=socket(AF_INET ,SOCK_STREAM, 0);
	if(sockfd<0)
	{
		perror("Socket Creation Failed");
		exit(-1);
	}
	struct sockaddr_in servaddr, cliaddr;
	memset(&cliaddr, 0, sizeof(cliaddr));
	memset(&cliaddr, 0, sizeof(servaddr));
	servaddr.sin_family = AF_INET;//IPv4
	servaddr.sin_addr.s_addr = INADDR_ANY; 
	servaddr.sin_port = htons(PORT);
	//memset(&buffer, 0, sizeof(buffer));
	if(bind(sockfd, (const struct sockaddr *)&servaddr, sizeof(servaddr))<0)
	{
		printf("\nBind Failed\n");
		exit(-1);
	}
	printf("Server is Running\n");
	listen(sockfd, 10);
	int n=0,newsock;
	
	pthread_t tid[10];
	int i=0;
	//struct info*client=malloc(sizeof(struct info)*10);

	while(1)
	{
		n = sizeof(cliaddr);
		newsock = accept(sockfd,(struct sockaddr*)&cliaddr,&n);
		struct info*client=malloc(sizeof(struct info));		
		client->ip = inet_ntoa(cliaddr.sin_addr);
		client->port = ntohs(cliaddr.sin_port);
		client->fd=newsock;
		printf("\nClient with Port %d connected Succesfully",client->port);
		pthread_create(&tid[i],NULL,func,(void*)client);
		
		if(tid[i]==0)
		{
			close(sockfd);
			exit(-1);
		}
		i++;
	}
	for(int j=0;j<=i;j++)
		pthread_join(tid[j],NULL);
return 0;
}

