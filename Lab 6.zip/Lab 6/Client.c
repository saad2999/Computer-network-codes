#include <pthread.h>
#include <stdio.h> 
#include <stdlib.h> 
#include <unistd.h> 
#include <string.h> 
#include <sys/types.h> 
#include <sys/socket.h> 
#include <arpa/inet.h> 
#include <netinet/in.h>
#define PORT 8080
#define MAXLINE 1024

int main()
{
    int sockfd;
    struct sockaddr_in servaddr;
	char buffer[MAXLINE]; 
	char hello[MAXLINE]; 
	
	sockfd = socket(AF_INET, SOCK_STREAM, 0);

	memset(&servaddr, 0, sizeof(servaddr)); 
	
    servaddr.sin_family = AF_INET; 
	servaddr.sin_port = htons(PORT); 
	servaddr.sin_addr.s_addr = INADDR_ANY; 
	
	connect(sockfd, (struct sockaddr *)&servaddr, sizeof(servaddr));
	printf("\nConnected with Server's port %d" " \n", ntohs(servaddr.sin_port));
	printf("Enter Message: \n");

	while(1)
	{
		memset(hello, '\0', MAXLINE);
		scanf("%s", hello);
		send(sockfd, hello, strlen(hello), 0);
		memset(buffer, '\0', MAXLINE);
		int n = recv(sockfd, buffer, MAXLINE, 0);
		buffer[n] = '\0';
		printf("Server Replied: %s\n", buffer);
		if(strcmp(buffer, "EXIT") == 0)
			break;
	}
	close(sockfd); 
    return 0;
}