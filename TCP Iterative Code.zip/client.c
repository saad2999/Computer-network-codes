#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <errno.h>
#include <string.h>
#include <netdb.h>
#include <sys/types.h>
#include <netinet/in.h>
#include <sys/socket.h>	
#define SERVPORT 3000 	 /* server well-known port */
#define SERVIP "127.0.0.1" 	 /* server IP adress */
#define MAXDATASIZE 1024 	/* max number of bytes we can get at once */

int main(int argc,char* argv[])
{
    int sockfd,numbytes;
    char buf[MAXDATASIZE];
    struct sockaddr_in serv_addr;
    sockfd=socket(AF_INET, SOCK_STREAM,0);
    serv_addr.sin_family= AF_INET;
    serv_addr.sin_port=htons(SERVPORT);
    serv_addr.sin_addr.s_addr=inet_addr(SERVIP);
    bzero(&(serv_addr.sin_zero),9);

    connect(sockfd, (struct sockaddr*)&serv_addr, sizeof(struct sockaddr));

    numbytes = recv (sockfd, buf, MAXDATASIZE, 0);
		
	buf[numbytes] ='\0';
	printf("Received: %s", buf);

	close (sockfd);

	return 0;
}   /* main function ends */
