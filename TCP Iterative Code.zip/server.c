#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>	

#define MYPORT 3000   /* my well-known port */
#define BACKLOG 1024 	 /* length of pending connections queue */

int main(void)
{
    int sockfd, new_fd;


    struct sockaddr_in my_addr;
    struct sockaddr_in cli_addr;
    int sin_size;
    sockfd=socket(AF_INET,SOCK_STREAM,0);
    my_addr.sin_family=AF_INET;
    my_addr.sin_port=htons(MYPORT);
    my_addr.sin_addr.s_addr=htons(INADDR_ANY);
    bzero(&(my_addr.sin_zero),8);

    bind(sockfd,(struct sockaddr *)&my_addr,sizeof(struct sockaddr));

    listen(sockfd,BACKLOG);
    while(1)
    {
        sin_size=sizeof(struct sockaddr_in);
        new_fd=accept(sockfd, (struct sockaddr*)&cli_addr, &sin_size);
        printf("Server: connection from %hhn",inet_ntoa(cli_addr.sin_addr));

        send(new_fd,"Hi this is server sending message\n",36,0);
        close(new_fd);
    }
    return 0;

}
